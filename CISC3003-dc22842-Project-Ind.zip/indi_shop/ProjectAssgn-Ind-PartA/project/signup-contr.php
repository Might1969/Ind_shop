<?php

class SignupContr{
    private $uid;
    private $pwd;
    private $pwdRepeat;
    private $email;
    
    public function __construct($uid, $pwd, $pwdRepeat, $email) {
        this->$uid = $uid;
        this->$pwd = $pwd;
        this->$pwdRepeat = $pwdRepeat;
        this->email = $email;
    }
}
?>
