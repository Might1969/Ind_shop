    </div>
  </body>
<footer>
<h2>DC228428 Zhang JiaQi</h2>
</footer>
</html>
<script src="js/script.js"></script>
